const Programs = () => {
  return (
    <div style={{ padding: "40px", color: "white" }}>
      <h1>Our Programs</h1>
      <p>
        Strength training, cardio, weight loss, and professional coaching.
      </p>
    </div>
  );
};

export default Programs;
